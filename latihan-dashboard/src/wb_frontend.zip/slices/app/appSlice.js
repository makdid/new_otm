import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  themeMode: localStorage.getItem("app") ? JSON.parse(localStorage.getItem("app"))?.themeMode : "light",
  wb: localStorage.getItem("app")
    ? JSON.parse(localStorage.getItem("app"))?.wb
    : {
        weight: -1,
        lastChange: 0,
        isStable: false,
        onProcessing: false,
        canStartScalling: false,
      },
};

export const appSlice = createSlice({
  name: "app",
  initialState,
  reducers: {
    setColorMode: (state, action) => {
      state.themeMode = action.payload;

      localStorage.setItem("app", JSON.stringify(state));
    },
    setWb: (state, action) => {
      state.wb = { ...state.wb, ...action.payload };

      localStorage.setItem("app", JSON.stringify(state));
    },
    clearWb: (state, action) => {
      state.wb = {
        weight: -1,
        lastChange: 0,
        isStable: false,
        onProcessing: false,
        canStartScalling: false,
      };

      localStorage.setItem("app", JSON.stringify(state));
    },
  },
});

// export default appSlice;
